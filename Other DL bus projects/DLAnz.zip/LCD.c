// 09.11.09, 22.04.08, H. Peters, LCD.c 4x27Zeichen
// ATMega88
#include "LCD.h"
// Portx:  0        1        2        3        4         5         6         7
// PortB:  Dat     Clk      Stb     MOSI     MISO      SCK       (Quarz    Quarz) 
//                                           LcdE1    LcdE2     
// PortC:  Tast0  Tast1    Tast2    Tast3     SDA      SCL        /RS       --
// PortD:  RxD      TxD     DL       RS      Lcd4     Lcd5       Lcd6      Lcd7

uint8_t Zeile;

void LCD_Strobe(void)
{
 if (Zeile<3)
 {
  PORTB |=   (1<<PB4); _delay_us(2);
  PORTB &=  ~(1<<PB4);
 }
 else
 {
  PORTB |=   (1<<PB5); _delay_us(2);
  PORTB &=  ~(1<<PB5); 
 }
  _delay_us(2);
}
        
void LCD_Disp(uint8_t b)
{
 PORTD = (PORTD&0x07) |  (b&0xF0)   | (1<<PD3); 
 LCD_Strobe(); 
 PORTD = (PORTD&0x07) |  (b<<4)     | (1<<PD3); 
 LCD_Strobe(); 
 LCDAnz++;
 _delay_us(40);
}

void LCD_Kom(uint8_t b)
{
 PORTD = (PORTD&0x07) |  (b&0xF0);
 LCD_Strobe(); 
 PORTD = (PORTD&0x07) |  (b<<4); 
 LCD_Strobe();
 _delay_ms(2);
}

void LCD_Zeile(uint8_t Nr)
{
 while (LCDAnz<27) LCD_Disp(' '); // Rest der alten Zeile mit Blanks f�llen
 Zeile = Nr&7;
 if (Zeile==1 || Zeile==3) LCD_Kom(0x80);
 if (Zeile==2 || Zeile==4) LCD_Kom(0xC0);
 if (Nr&0x80) LCD_Kom(0x01); // 2 Zeilen l�schen
 LCDAnz = 0;
}

void LCD_Init(void)
{
 /* RS = 0: Instruction */
 LCD_Kom(0x03); 
 LCD_Kom(0x03);
 LCD_Kom(0x03);
 LCD_Kom(0x02);  /* 4Bit Interface */

 /* Function set: 2 lines, 5x7 CharSet [5x10: 0Ch statt 08h] */
 LCD_Kom(0x28); 

 /* Entry mode: Increment+1; S=0: kein Disp-Shift  */
 LCD_Kom(0x06);

 /* Disp on, Curs on, blink on  */
 LCD_Kom(0x0F);
 LCD_Kom(0x0C); // Cursor aus

 /* Clear display */
 LCD_Kom(0x01); 
}

void LCDTxt_P(const prog_char Txt[]) // Txt zeigt auf Adr. im Flash
{
uint8_t Zeich, i=0;
 while ( (Zeich=pgm_read_byte(Txt++)) !=0 && i<27) {LCD_Disp(Zeich); i++;}
}





