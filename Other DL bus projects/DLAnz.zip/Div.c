#include "Div.h"
#include "LCD.h"


void ADez(int16_t Wert, uint8_t St) // St: 0;1..5: Anzahl auszugebender Stellen
{
uint8_t fBits = 0x03; //Bit0=1: f�hrende Blanks (feste Stellenl�nge); Bit1=1: keine f�hrende Nullen
uint16_t DivMuster[5] = {10000,1000,100,10,1}; /* zur Umcodierung */
uint16_t DivMust, hWert;
 if (St&0x80) fBits &= ~0x02; // f�hrende Nullen ausgeben
 if (St&0x40) fBits |=  0x08; // Dp vor letzter Stelle
 if (St&0x10) fBits |=  0x04; // nachfolgendes Blank
 if ( (Wert<0) && ((St&0x20)==0) ) {hWert = -Wert; fBits |=  0x10;} else hWert = Wert;
 St &= 0x07;
 if (St==0) {St = 5; fBits &= ~0x01; } // keine f�hrenden Blanks, Stellenl�nge nach Bedarf
 
 while (St)
 {uint8_t j;
  DivMust = DivMuster[5-St];
  j = 0;
  while (hWert>=DivMust)
  {
   hWert = hWert - DivMust;
   j++;
   fBits &= ~0x02; // hier Ziffer<>0 
  }
  if (St==1) fBits &= ~0x02;      // sp�testens bei letzter Stelle evtl. 0 ausgeben
  if (St==2 && (fBits&0x08) ) fBits &= ~0x02; 
  if (fBits&0x02) j = ' '-48;     // bei f�hrender Null Blank ausgeben
  j += 48;                        // in ASCII
  if (j!=' ')
  { 
   if (fBits&0x10) {fBits &= ~0x10; SendZeich('-');}
   SendZeich(j);
  }
  else if (fBits&0x01) SendZeich(j); 

  if ( (fBits&0x08) && St==2) SendZeich('.');
  St--;
 }
 if (fBits&0x04) SendZeich(' ');
}


void SendZeich(uint8_t Zeich) // 
{
 if (SendArt&0x80) LCD_Disp(Zeich); 
 if (SendArt&0x40) return;
}


void SendTemp(int16_t Temp)  // alle Temp. um Faktor=10 erh�ht
{
 if (Temp<=-100)     ADez(Temp/10,0x13); // "-99  "
 else if (Temp<0)    ADez(Temp,0x52);    // "-9.9 " .. "-0.9 "
 else if (Temp<1000) ADez(Temp,0x53);    // "99.9 "
 else                ADez(Temp/10,0x14); // "999  "
}


