// 15.07.08, DLAnz.c, Harald Peters
// Portx:  0        1        2        3        4         5         6         7
// PortB:  Dat     Clk      Stb     MOSI     MISO      SCK       (Quarz    Quarz) 
//                                  RelA     LcdE1    LcdE2     
// PortC:  Tast0  Tast1    Tast2    Tast3     SDA      SCL        /RS       --
// PortD:  RxD      TxD     DL       RS      Lcd4     Lcd5       Lcd6      Lcd7
// Mega88, FuseBitsL: statt 62h E2h (8MHz, intern, 1:1),    Kommando ACh A0h 00h E2h
// Mega88, FuseBitsH: statt DFh D4h (EE nicht l�schen,BOD), Kommando ACh A8h 00h D4h
// Mega88, FuseBitsE: statt F9: FC: Bootloader 512Byte

// StatusLED:
// (links) 7    6    5    4    3    2    1    0 (rechts)
//  rot  8000 2000 0800 0200 0080 0020 0008 0002
// gr�n  4000 1000 0400 0100 0040 0010 0004 0001

#include "Div.h"
#include "LCD.h"


prog_char Version_p[] = "DLAnz, V1.14, Harald Peters, 15.07.08\r\n";

volatile uint8_t  tsek, hsek, NeuSek;
uint8_t  h10ms, t10ms, Dauer10msMin = 100;
uint8_t  OCRdef = 78;

uint8_t  BitZ, BytZ, DByte, DFert, DSim, DAusfall;
uint16_t AnzDLFhl, AnzDLges, DAusfallDauer;
uint16_t StatusLED;

uint8_t  Tast[4], TastG, LCDArt, LCDArtAlt;

uint8_t  EEAend, StatSolPmp, StatVFPmp, BRein, NeuTag, TagZust;

volatile uint8_t RxZaehl;
uint8_t          RxBuffer[32], RxLen;

// zur Berechnung KWh/Tag; alle Werte in 0.1KWh
uint16_t KWhTag, KWhGestern;
uint32_t KWhGes, KWhAlt;
uint32_t KWhGesEE EEMEM;

struct tDL // 65Byte
{
/* 00 */ uint16_t Kennung;
/* 02 */ uint8_t  xxx;
/* 03 */ uint8_t  Min, Std, Tag, Mon, Jhr;
/* 08 */ int      Temp[16];
/* 40 */ uint16_t Ausg;
/* 42 */ uint8_t  Drehz[4], WReg, KW100;
/* 48 */ int16_t  KW1;   // max 6553.1KW
/* 50 */ uint8_t  KW1H; // immer 0
/* 51 */ uint16_t KWh, MWh;
/* 55 */ uint32_t KW2, MWh2;
/* 63 */ uint8_t  PSum;
/* 64 */ uint8_t  PSumNeu;
};
/* Temp-Sensoren:
  0: Speicher oben;  1: Warmwasser;   2: Speicher unten; 3: Speicher Mitte
  4: Solarvorlauf;   5: Solarr�ckl.;  6: WW-R�cklauf;    7: Kollektor Ost
  8: Kollektor West; 9: Au�enf�hler; 10: Zirkulation;   11: Hz-Vorlauf
 12: Keller;        13: RF I (KS);   14: Vol.-Strom     15: RF II (Wz)
*/
union tDLPuffer
{
 uint8_t b[65];
 struct tDL t;
} DLPuffer, DLWerte;


struct tZeiten
{ //      
 uint8_t  PmpAusFakt, PmpEinFakt;              // projektierte Werte
 uint8_t  StartEinZeit, StartAusZeit;          // projektierte Werte
 uint16_t PmpAusZeit, PmpEinZeit;              // berechnete Werte
 uint16_t PmpAusDauer, PmpEinDauer, ZyklDauer; // laufende Werte
 uint8_t  PmpProzent,VFist,ZyklProzent;
 uint32_t PmpGesSek, TagGesSek;
} Z =
{
 60, 30,  // projektierte Werte
 15, 30  // projektierte Werte in Sek.
};

enum tPhase
{
 StartVFPmpAus,VFPmpAus, StartPmpEin,StartPmpKurzAus,PmpKurzAusPhase,PmpEinPhase, 
 StartPmpAus,PmpAusPhase
} Phase;

struct tEEZeiten
{
 uint8_t PmpAusFakt, PmpEinFakt;
 uint8_t  StartEinZeit, StartAusZeit; 
} EEZeiten EEMEM;



void AuswertungDL(void) // Temp.+Zeit korr. + Statusauswertungen
{uint8_t i;
 for (i=0; i<16; i++) // Umwandlung in Integer
 {
  if (DLWerte.t.Temp[i]&0x8000) DLWerte.t.Temp[i] |=  0xF000;
  else                          DLWerte.t.Temp[i] &= ~0xF000; 
 }

 DLWerte.t.Std &= 0x1F; // Sommerzeit-Bit maskieren
 if ( ( DLWerte.t.Std + DLWerte.t.Min)<2 ) NeuTag |= 0x80; // 00:00
 else if (NeuTag&0x80)                     NeuTag  = 0x01; // 00:01

 if ( (DLWerte.t.Std>=6) && (DLWerte.t.Std<22) )  // Tag/Nacht bestimmen
 {
  if ( (TagZust&0x01)==0) TagZust = 0x81;         // Bit7: Flag f�r Wechsel
 }
 else 
 {
  if ( (TagZust&0x01)>0 ) TagZust = 0x80;
 }

 if ((DLWerte.t.Ausg>>0) & 1) // Solarpumpe ist ein
 { 
  if ( (StatSolPmp&0x01)==0x00) {StatSolPmp = 0x81;} // Bit7: Flag f�r Wechsel
 }
 else // Solarpumpe ist aus
 {
  if ( (StatSolPmp&0x01)==0x01) {StatSolPmp = 0x80;}  
 }

 if ((DLWerte.t.Ausg>>5) & 1) // VF-Pumpe ist ein
 { 
  if ( (StatVFPmp&0x01)==0x00) {StatVFPmp = 0x81;} // Bit7: Flag f�r Wechsel
 }
 else // VF-Pumpe ist aus
 {
  if ( (StatVFPmp&0x01)==0x01) {StatVFPmp = 0x80;}  
 }

 BRein = (DLWerte.t.Ausg>>11) & 1; // Status Brenner

 Z.VFist = DLWerte.t.Temp[11]/10;
 // Begrenzungen,  Z.VFist wird f�r PmpEin-, -AusZeit gebraucht
 if (Z.VFist<20) Z.VFist = 20;
 if (Z.VFist>60) Z.VFist = 60;
 
 KWhGes = 10000*DLWerte.t.MWh + DLWerte.t.KWh; // Angabe in 0.1KWh
 if (KWhAlt) KWhTag = KWhGes-KWhAlt; // nach Reset nicht berechnen
}


void BerechneAusEinZeiten(uint8_t Aus) // 
{
 if (Aus) Z.PmpAusZeit = (61-Z.VFist) * Z.PmpAusFakt;
 else     Z.PmpEinZeit = (Z.VFist)    * Z.PmpEinFakt;
}

void RelVFPmp(void) // zykl. Aufruf 1/s
{
  if (StatVFPmp&0x80)  // Solvis-Regler hat Zustand Pmp ge�ndert
  {
    StatVFPmp &= ~0x80;// WechselBit kann gel�scht werden

    if (StatVFPmp&1)   // Solvis-Regler hat Pmp eingeschaltet
     Phase = StartPmpEin;
    else               // Solvis-Regler hat Pmp ausgeschaltet
     Phase = StartVFPmpAus;
  }

  // Beginn Tag, Flag(Bit7) wird gleich gel�scht; 06.06.08
  if ( (TagZust&0x81)==0x81 ) {if (Phase!=VFPmpAus) Phase = StartPmpEin;}

  // Beginn Nacht, Flag(Bit7) wird gleich gel�scht; 06.06.08
  if ( (TagZust&0x81)==0x80 ) {if (Phase!=VFPmpAus) Phase = StartPmpAus;}

  switch (Phase) // StartPmpAus,PmpAusPhase,StartPmpEin,PmpEinPhase,StartPmpNachlauf,PmpNachlaufphase
  {
    case StartVFPmpAus: // Solvis-Regler hat Pmp ausgeschaltet
     PORTB &= ~(1<<PB3);   // Abschaltrelais kann ausgeschaltet werden
     StatusLED &= ~0x0020; // rt aus, gn war schon aus
     Phase = VFPmpAus;
     Z.ZyklDauer = 0; 
    break;

    case VFPmpAus: // Solvis-Regler hat Pmp ausgeschaltet
     // Phase kann sehr lange dauern
     if (StatVFPmp) Phase = StartPmpEin;
    break;
//-----------------------------------------------------------------------------------
    case StartPmpEin:
     PORTB &= ~(1<<PB3); // Abschaltrelais ausschalten
     StatusLED |= 0x0020; // rt
     // rel. Laufzeit letzter Zyklus
     if (Z.ZyklDauer) Z.ZyklProzent = (100UL*(uint32_t)Z.PmpEinZeit)/(uint32_t)Z.ZyklDauer;
     Z.ZyklDauer = 0; 
     BerechneAusEinZeiten(0);
     // wenn TagAnfang, dann Wert verdoppeln
     if ( (TagZust&0x81)==0x81 ) {TagZust &= ~0x80; Z.PmpEinZeit *= 2;}
     Z.PmpEinDauer = Z.PmpEinZeit;
     Phase = PmpEinPhase;
    break;

    case PmpEinPhase:
     Z.ZyklDauer++;
     // nur einmal zu Anfang: kurze Zwischenabschaltung wegen Mischerregelung
     if (Z.ZyklDauer==(uint16_t) Z.StartEinZeit) Phase = StartPmpKurzAus; // nur 1x m�glich
     Z.PmpGesSek++;
     Z.PmpEinDauer--;
     if (Z.PmpEinDauer==0) Phase = StartPmpAus;
     if (BRein)            Phase = StartPmpEin;
    break;

    case StartPmpKurzAus: // nur einmal nach Beginn der Einphase
     PORTB |= (1<<PB3); // Abschaltrelais einschalten
     Z.PmpAusDauer = Z.StartAusZeit; // Pausenzeit, wenn Zeit verstrichen, dann Pmp ein
     Phase = PmpKurzAusPhase;
    break;

    case PmpKurzAusPhase:
     StatusLED ^= 0x0020; // rt blinken
     StatusLED ^= 0x1000; // gn blinken
     Z.ZyklDauer++;
     Z.PmpAusDauer--;
     if (BRein) Z.PmpAusDauer = 0; // Br ist eingeschaltet worden
     if (Z.PmpAusDauer==0)
     {
      PORTB &= ~(1<<PB3);  // Abschaltrelais ausschalten
      StatusLED |= 0x0020; // rt
      StatusLED &=~0x1000; // gn
      Phase = PmpEinPhase; // kurze Pause ist um, weiter in alter Einphase
     }
    break;

    case StartPmpAus:   // eigentliche Ausphase
     PORTB |= (1<<PB3); // Abschaltrelais einschalten
     BerechneAusEinZeiten(1);
     // wenn NachtAnfang, dann Wert verdoppeln
     if ( (TagZust&0x81)==0x80 ) {TagZust &= ~0x80; Z.PmpAusZeit *= 2;}
     Z.PmpAusDauer = Z.PmpAusZeit; // Pausenzeit, wenn Zeit verstrichen, dann Pmp ein
     Phase = PmpAusPhase;
    break;

    case PmpAusPhase:
     StatusLED ^= 0x0020; // rt blinken
     Z.ZyklDauer++;
     Z.PmpAusDauer--;
     if (Z.PmpAusDauer==0) Phase = StartPmpEin; // Pmp wieder einschalten, da Pause um
     if (BRein)            Phase = StartPmpEin; // Br ist eingeschaltet worden
    break;
  } // switch (Phase)

  Z.TagGesSek++;

  if (NeuTag==1) // um 00:01
  {
   Z.PmpProzent = (Z.PmpGesSek*100)/Z.TagGesSek;
   Z.PmpGesSek = 0; Z.TagGesSek = 0;
   AnzDLFhl = 0; AnzDLges = 0;
   KWhGestern = KWhTag; KWhTag = 0; KWhAlt = KWhGes; // zur Berechnung KWh/Tag
   eeprom_write_block(&KWhGes,&KWhGesEE,sizeof(KWhGesEE));
   NeuTag = 0;
  }
}


void LCDAusg(void)
{
 SendArt = 0xC0; // Daten zum LCD statt UART
 LCD_Zeile(1); if (LCDArt!=LCDArtAlt) {LCD_Init(); LCD_Kom(0x0C);} // Cursor aus
 {// 15 Zeichen
  ADez(DLWerte.t.Tag,0x82); SendZeich('.'); ADez(DLWerte.t.Mon,0x82); SendZeich('.'); 
  ADez(DLWerte.t.Jhr,0x82); SendZeich(' ');
  ADez(DLWerte.t.Std,0x82); SendZeich(':'); ADez(DLWerte.t.Min,0x92); 
  if (AnzDLges&1)  SendZeich('*'); else SendZeich(' ');
  LCDTxt(" AF:"); SendTemp(DLWerte.t.Temp[9]); 
 }
 
 
 LCD_Zeile(2);
 
 if (LCDArt!=2 && LCDArt!=5) // LCDArt=0,1, 3,4: Zeile 2 konstant
 {
  LCDTxt("PufO:"); SendTemp(DLWerte.t.Temp[ 0]); 
  LCDTxt("Pm:");   SendTemp(DLWerte.t.Temp[ 3]); 
  LCDTxt("Pu:");   SendTemp(DLWerte.t.Temp[ 2]); 
  LCD_Zeile(3);
 }
 
 if (LCDArt<2) // LCDArt=0,1: 3.Zeile konstant
 {int16_t kTemp = DLWerte.t.Temp[ 7];
  LCDTxt("Kol");
  if (DLWerte.t.Temp[ 8]>DLWerte.t.Temp[ 7]) {LCDTxt("W:"); kTemp = DLWerte.t.Temp[ 8];} 
  else                                       {LCDTxt("O:"); }
                   SendTemp(kTemp);
  LCDTxt("Kt:");   SendTemp(KWhTag); 
  LCDTxt("Kg:");   ADez(KWhGes/10,0x00);
  LCD_Zeile(4);
 }

 if (LCDArt==0) // kein Solarbetrieb, nur Zeile 4
 {
  LCDTxt("Wohn:"); SendTemp(DLWerte.t.Temp[15]); 
  LCDTxt("VF:");   SendTemp(DLWerte.t.Temp[11]); 
  LCDTxt("Ke:");   SendTemp(DLWerte.t.Temp[12]);   
 }
 else if (LCDArt==1) // Solarpumpe ein, nur Zeile 4
 {
  LCDTxt("SolV:"); SendTemp(DLWerte.t.Temp[ 4]); 
  LCDTxt("Vl:");   SendTemp(DLWerte.t.Temp[14]*40); // wegen Temp mal 10; mit Dez.-Pkt
  LCDTxt("KW:");   SendTemp(DLWerte.t.KW1);
 }
 else if (LCDArt==2) // sonstige Werte, Zeile 2,3,4
 {
  LCDTxt("KolO:"); SendTemp(DLWerte.t.Temp[ 7]); 
  LCDTxt("KW:");   SendTemp(DLWerte.t.Temp[ 8]); 
  LCDTxt("Kg:");   SendTemp(KWhGestern); 
  LCD_Zeile(3);
  LCDTxt("SolV:"); SendTemp(DLWerte.t.Temp[ 4]); 
  LCDTxt("Sr:");   SendTemp(DLWerte.t.Temp[ 5]); 
  LCDTxt("Kh:");   SendTemp(KWhTag); 
  LCD_Zeile(4);
  LCDTxt("WrmW:"); SendTemp(DLWerte.t.Temp[ 1]); 
  LCDTxt("KW:");   SendTemp(DLWerte.t.Temp[ 6]); 
  LCDTxt("Zk:");   SendTemp(DLWerte.t.Temp[10]); 
 }
 else if (LCDArt==3 || LCDArt==4)
 {
  BerechneAusEinZeiten(1);
  LCD_Kom(0x0F); // Cursor ein
  LCDTxt("AusFakt="); ADez(Z.PmpAusFakt,0x10); 
  LCDTxt("VF:"); ADez(Z.VFist,0x10); ADez(Z.PmpAusZeit,0x10); ADez(Z.PmpAusDauer,0x10);
  LCD_Zeile(4);
  BerechneAusEinZeiten(0);
  LCDTxt("EinFakt="); ADez(Z.PmpEinFakt,0x10); 
  LCDTxt("VF:"); ADez(Z.VFist,0x10); ADez(Z.PmpEinZeit,0x10); ADez(Z.PmpEinDauer,0x10);
  if (LCDArt==3) LCD_Kom(0x02); // Cursor Home
 }
 else if (LCDArt==5)
 {
  LCD_Zeile(3);
  if (DAusfall)
  {
   LCDTxt("Ausfall DL "); ADez(DAusfallDauer,0x10);
  }
  else 
  {
   LCDTxt("Pmp:"); ADez(Z.PmpGesSek,0x00);  LCDTxt("s Tag:"); 
   ADez(Z.TagGesSek,0x20); LCDTxt("s "); ADez((100*Z.PmpGesSek)/Z.TagGesSek,0x00); SendZeich('%');
   LCD_Zeile(4);
   LCDTxt("Pmp:"); ADez(Z.PmpProzent,0x00); LCDTxt("% Zykl:"); ADez(Z.ZyklProzent,0x00); LCDTxt("% ");
   ADez(AnzDLges,0x30); ADez(AnzDLFhl,0x00); LCDTxt("Fhl");
  }
 }

 SendArt = 0x00;
 LCDArtAlt = LCDArt;

//1   5    0    5    0    5 7
//AusFakt=30 VF:55 2499 2222
//Pmp:12000s Tag:32000s 44%
}

void DL_Ausfall(void) // keine DL-Daten!
{
  StatusLED &= ~(0x0FFF); // alle LEDs bis auf die beiden links aus
  PORTB &= ~(1<<PB3);     // Pmp-Abschaltrelais aus
}


void DekodeAusg(void)
{uint8_t Bit, i = 0;

 while (i<16)
 {
  Bit = (DLWerte.t.Ausg>>i) & 1;
  switch (i)
  {
   case 0: // Solar-Pmp
    if (Bit) 
    {
      StatusLED |= 0x0400; // gn
      if (DLWerte.t.Temp[15]>30) StatusLED |= 0x0800; // rt
    } 
    else StatusLED &= ~(0x0800|0x0400); 
   break;

   case 1: // WW-Pmp
    if (Bit) StatusLED |= 0x0080; else StatusLED &= ~0x0080; // rt
   break;

   case 2: // Kollektor SO
    if (Bit) StatusLED |= 0x0100; else StatusLED &= ~0x0100; // gn
   break;

   case 3: // Kollektor SW
    if (Bit) StatusLED |= 0x0200; else StatusLED &= ~0x0200; // rt
   break;

   case 4: // Zirkulations-Pmp
    if (Bit) StatusLED |= 0x0040; else StatusLED &= ~0x0040; // gn
   break;

   case 5: // Vorlauf-Pmp
    if (Bit) StatusLED |= 0x0010; else StatusLED &= ~0x0010; // gn
   break;

   case 7: // Mischer Auf
    if (Bit) StatusLED |= 0x0008; else StatusLED &= ~0x0008; // rt
   break;

   case 8: // Mischer Zu
    if (Bit) StatusLED |= 0x0004; else StatusLED &= ~0x0004; // gn
   break;

   case 11: // Brenner
    if (Bit) StatusLED |= 0x0001; else StatusLED &= ~0x0001; // gn
   break;

   case 12: // Brenner
    if (Bit) StatusLED |= 0x0002; else StatusLED &= ~0x0002; // rt
   break;
  }
  i++;
 }
}


ISR(TIMER2_COMP_vect) // 100/sek, 10ms
{uint8_t i;
 for (i=0; i<4; i++)
 {
   if ( (PINC&(1<<i) )==0) Tast[i] = (Tast[i]+1) | 0x80;
   else if (Tast[i]&0x80) {TastG = i+1; Tast[i]&=~0x80;} 
 }

 h10ms++;
 if (h10ms<16)
 {
  if (((StatusLED>>h10ms)&1)>0) PORTB |=  (1<<PB0); else PORTB &=  ~(1<<PB0);

  PORTB |=  (1<<PB1); PORTB &=  ~(1<<PB1); // 1 Clock-Takt
 } else if (h10ms==16) /* if (h10ms<16) */
 {
   PORTB |=  (1<<PB2); PORTB &=  ~(1<<PB2); // 1 Strobe-Takt alle 160ms
   h10ms = 255;
 }

 t10ms++;
 if (t10ms==Dauer10msMin) 
 { t10ms = 0;
   hsek++;
   tsek++; // �berwachung DL
   NeuSek = 1;
 }  

}



ISR(INT0_vect) // warten auf Startbit DL
{
 if (BytZ==0) // warten auf 16Synchbits
 {
  if (TCNT0>80 || TIFR0 ) // TCNT0=64: 64*32us = 2048us
  {
   if (BitZ<12) // Synchrahmen noch nicht gefunden
   {
    BitZ = 0;
   }
   else // Start nach >11 Einsbits gefunden
   {
    BitZ = 0;
    OCR0A = 48; // 1536us
    TIMSK0 |=  (1<<OCIE0A); // Int bei TNCT0=OCR0A
    EIMSK  &= ~(1<<INT0);   // Int0 aus
    DLPuffer.b[64] = 0;
   }
  } // if (TCNT0>80)
  else
  {
   BitZ++; 
  }
 }
 else // if (BytZ==0)
 { // Startflanke neues Byte aufgetreten:
    BitZ = 0;
    OCR0A = 48; // 1536us -> nur g�ltig 1.Bit
    TIMSK0 |=  (1<<OCIE0A); // Int bei TNCT0=OCR0A
    EIMSK  &= ~(1<<INT0);   // Int0 aus
 }

 TCNT0 = 0;
 TIFR0 = 7; // Timerflags l�schen
}


ISR(TIMER0_COMPA_vect) // zuerst 1536us, dann alle 2048us 
{
 OCR0A = 64; // 2048us, f�r Bits1..8 wirksam

 if (BitZ<8) // 0..7 Datenbits, LSB zuerst
 {
  if (PIND & (1<<PD2)) DByte |= (1<<BitZ);
 }
 else // if (BitZ==9) // BitZ=8 ist Stopbit
 { // auf n�chste Startflanke warten:
  TIMSK0 &= ~(1<<OCIE0A);  // Int bei TNCT0=OCR0A aus
  DLPuffer.b[BytZ] = DByte;
  if (BytZ<63) DLPuffer.b[64]  += DByte;
  DByte = 0;
  BytZ++;
  if (BytZ==64) // alle Bytes eingelesen
  { 
   if (DSim&0x10) DFert = 1;
  }
  else // Int0 freischalten f�r neues Startbit
  {
   EIFR   |=  (1<<INTF0);   // evtl. altes Int-Flag l�schen 
   EIMSK  |=  (1<<INT0);    // Int0 wieder ein
  }
 }
 BitZ++;
}


ISR(USART_RX_vect)
{uint8_t Zeich;
  if (RxZaehl<sizeof(RxBuffer) )
  {
   Zeich = UDR0;
   if (RxZaehl==0)
   {
    if (Zeich=='%' || Zeich=='&') RxLen = 5; // damit kein Abbruch, wenn Adr oderLen 0x0A enth�lt
    else                          RxLen = 1;
   }
   RxBuffer[RxZaehl] = Zeich; RxZaehl++;
   if (RxZaehl>RxLen && Zeich==0x0A) RxZaehl = 255;
  }
  else RxZaehl = 255;
}




//...................................................................................................
int main(void)
{
/*
 memset(&RS232SPuffer,0,sizeof(RS232SPuffer));SPufferWr=0; SendTemp(-999); // "-99  "
 memset(&RS232SPuffer,0,sizeof(RS232SPuffer));SPufferWr=0; SendTemp(- 99); // "-9.9 "
 memset(&RS232SPuffer,0,sizeof(RS232SPuffer));SPufferWr=0; SendTemp(-  9); // "-0.9 "
 memset(&RS232SPuffer,0,sizeof(RS232SPuffer));SPufferWr=0; SendTemp(+  9); // "0.9  "
 memset(&RS232SPuffer,0,sizeof(RS232SPuffer));SPufferWr=0; SendTemp(+ 99); // "9.9  "
 memset(&RS232SPuffer,0,sizeof(RS232SPuffer));SPufferWr=0; SendTemp(+999); // "99.9 "
 memset(&RS232SPuffer,0,sizeof(RS232SPuffer));SPufferWr=0; SendTemp(9999); // "999  "
 */
 wdt_disable();
 PORTD |= (1<<PD0); // Pull-up an RxD einschalten
 EICRA =  (1<<ISC00) | (1<<ISC01); // steigende Flanke Int0
 EIMSK |= (1<<INT0);
 OCR0A = 255;
 TCCR0A  =  (1<<WGM01);  // CTC-Modus
 TCCR0B  =  (1<<CS02); // Start Timer 1:256 -> alle 32us Inkr.
 OCR2A = OCRdef;
 TCCR2A = (1<<WGM21);
 TCCR2B = (1<<CS22) | (1<<CS21) | (1<<CS20); // Timer2 starten mit 1:1024
 TIMSK2 = (1<<OCIE2A); // Enable Timer2 Output Compare Interrupt

 uint8_t i;
 i = eeprom_read_byte(&EEZeiten.PmpAusFakt);
 if (i && i!=0xFF)  eeprom_read_block(&Z,&EEZeiten,sizeof(EEZeiten));
 eeprom_read_block(&KWhGes,&KWhGesEE,sizeof(KWhGesEE));
 if (KWhGes==0xFFFFFFFF) KWhGes = 0;


 DSim = 0x1F; // nur f�r Tests
 sei();

 _delay_ms(1000);
 DDRB   =  0x3F; // 4094,LCD
 DDRD   =  0xF8; // LCD
 PORTC  =  0x0F; // Pull Up Taster
 PORTD |=  (1<<PD2); // Pull Up DL


 LCD_Init();
 LCD_Zeile(1); LCDTxt_P(Version_p);
 LCD_Zeile(2); LCDTxt  ("Zeile 2");
 LCD_Zeile(3); LCD_Init();
               LCDTxt  ("Zeile 3");
 LCD_Zeile(4); LCDTxt  ("Zeile 4");
 StatusLED = 0x8000; //rt

 tsek = 0;
 while (tsek<2);

 LCD_Zeile(1); LCD_Init();
 LCD_Zeile(3); LCD_Init();

 TastG = 0;
 DAusfall = 0x00;

 wdt_enable(WDTO_1S);

 for(;;)   // Hauptschleife
 { 
  wdt_reset();

  if (TastG)
  {
   LCD_Zeile(3); LCD_Init();
   LCD_Zeile(1); LCD_Init();

   if (TastG==1)
   {
    if (LCDArt <2) {Phase = StartPmpEin;}
    if (LCDArt==3) {Z.PmpAusFakt++; EEAend = 1;}
    if (LCDArt==4) {Z.PmpEinFakt++; EEAend = 1;}
   } else

   if (TastG==2)
   {
    if (LCDArt <2) {Phase = StartPmpAus;}
    if (LCDArt==3) {Z.PmpAusFakt--; EEAend = 1;}
    if (LCDArt==4) {Z.PmpEinFakt--; EEAend = 1;}
   } else

   if (TastG==3)
   {
    LCDArt++; if (LCDArt>5) LCDArt = 0;
    hsek = 0; // Zeit�berwachung
   } else

   if (TastG==4)
   {
    LCDArt--; if (LCDArt==255) LCDArt = 5;
    hsek = 0; // Zeit�berwachung
   }

   TastG = 0;
  }

  if (DFert) // Datensatz eingelesen
  {
    DFert = 0;
    if (DSim&1) memcpy(&DLWerte,&DLPuffer,sizeof(DLPuffer)); // in DLWerte kopieren
    BytZ = 0;

    OCR0A = 255;
    EIFR   |=  (1<<INTF0);
    EIMSK  |=  (1<<INT0); // damit kann der folgende Rahmen gelesen werden
    if (DLPuffer.b[63]==DLPuffer.b[64]) // Pr�fsumme stimmt
    {
     if (DAusfall==0x01) // Ende Ausfall
     {
      DAusfall = 0;
      StatusLED &= ~0x8000; // rt aus
      LCDArt = 0;
      StatSolPmp = 0x80; // autom. Umschaltung in LCDArt=1, falls Solar
     }
     StatusLED |= 0x4000; // gn
     AnzDLges++;
     AuswertungDL();

     if ( (StatSolPmp&0x80) && LCDArt<2) // �nderung
     {
      StatSolPmp &= ~0x80;
      if (StatSolPmp==0) LCDArt = 0;
      else               LCDArt = 1;
     }

     if (DSim&2) DekodeAusg();
     if (DSim&4) LCDAusg();
     tsek = 0; // f�r TimeOut
    }
    else // Pr�fsummenfehler
    {
     AnzDLFhl++;
     StatusLED &= ~0x4000;
    }
  }

 
  if (NeuSek) // 1 pro Sekunde
  {
   NeuSek = 0; 

   if (tsek>5) // keine DL-Daten mehr
   {
    tsek = 0; 
    if ( (DAusfall&0x01)==0 ) // Beginn Ausfall
    {
     DAusfall = 0x01;
     DAusfallDauer = 0;
     DL_Ausfall();
     LCDArt = 5;
    }
   }

   if (DAusfall) 
   {
    DAusfallDauer++;
    StatusLED ^= 0x8000; // rt blinken
    if (DSim&4) LCDAusg(); // sonst LCD-Akt. �ber DFert
   }
   else if (DSim&8) RelVFPmp(); // bei DAusfall keine VF-Pmp Steuerung

   if ( (LCDArt==3 || LCDArt==4) && hsek>240)  // Zeit�berwachung 4min
   {
    if (StatSolPmp&1) LCDArt =  1; else LCDArt =  0;

    if (EEAend)
    {
     eeprom_write_block(&Z,&EEZeiten,sizeof(EEZeiten));
     EEAend = 0;
    }
   }
  }

 } // for
 return 0;
} // main

