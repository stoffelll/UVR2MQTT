// LCD.h; 09.11.09, 21.04.08
#ifndef LCD_h
#define LCD_h
#include <avr/io.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <util/delay.h>

uint8_t Zeile, LCDAnz;
void LCD_Disp(uint8_t b);
void LCD_Kom(uint8_t b);
void LCD_Init(void);
void LCD_Zeile(uint8_t Nr);
void LCDTxt_P(const prog_char Txt[]); // Txt zeigt auf Adr. im Flash
#define LCDTxt(format) LCDTxt_P(PSTR(format))  



#endif
