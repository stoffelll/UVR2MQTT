
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/eeprom.h>
#include <stdarg.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <avr/wdt.h>
#include <util/delay.h>

#ifndef _DIV_H
 #define _DIV_H

#ifdef _AVR_IOMX8_H_ // falls Mega88 gew�hlt
// Achtung: Festlegung gilt standardm��ig f�r Mega8/16/32,
// immer �berpr�fen bei Prozessorwechsel, ob Zuordnung pa�t!
//     8/16/32 88
 #define UDR   UDR0
 #define UCSRA UCSR0A
 #define UDRE  UDRE0
 #define UBRRH UBRR0H
 #define UBRRL UBRR0L
 #define UCSRB UCSR0B
 #define RXEN  RXEN0
 #define TXEN  TXEN0
 #define TXC   TXC0
 #define RXCIE RXCIE0
 #define USART_RXC_vect USART_RX_vect
 #define TCCR0 TCCR0B // gilt nur f�r Vorteilung
 #define TCCR2 TCCR2B // 
 #define TIMSK TIMSK0 // gilt nur f�r Overflow und Compare Match A (TOIE0,OCIE0)
 #define TIMER2_COMP_vect TIMER2_COMPA_vect
#endif

/*
// Word = (uint16_t ) Feld;         // �bergibt Adresse von Feld an Word
// Word = (uint16_t ) Feld[1];      // �bergibt Inhalt[1] von Feld an Word
// Word = Feld[1] | (Feld[2]<<8);   // �bergibt Inhalt[1,2] von Feld an Word; braucht 16 Byte mehr
// Word = Feld[1] + (Feld[2]<<8);   // �bergibt Inhalt[1,2] von Feld an Word; braucht 10 Byte mehr
// Word = *((uint16_t *) &Feld[1]); // �bergibt Inhalt[1,2] von Feld an Word; effektivste L�sung
   deswegen Makro zum Word-Lesen von Byte-Feldern, z.B Word = WordTrans(Sektor[10]): */
#define  WordTrans(Feld) (*( (uint16_t *) &Feld) )
uint8_t SendArt;

#define Printf(format, args...) printf_P(PSTR(format) , ## args)

void SendZeich(uint8_t x);
void ADez(int16_t Wert, uint8_t St); // St: 0;1..5: Anzahl auszugebender Stellen
void SendTemp(int16_t Temp);  // Temp um Faktor=10 erh�ht


#endif
