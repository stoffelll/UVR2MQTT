<?php
  
/**
 * Initiates API
 *
 * @package default
 */

require_once dirname(__FILE__).'/include/init.inc.php';

new Api();
  
?>