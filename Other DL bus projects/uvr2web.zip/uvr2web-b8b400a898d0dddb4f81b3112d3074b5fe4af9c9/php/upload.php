<?php

/**
 * Initiates the uploader
 *
 * @package default
 */

require_once dirname(__FILE__).'/include/init.inc.php';

new Uploader();

?>