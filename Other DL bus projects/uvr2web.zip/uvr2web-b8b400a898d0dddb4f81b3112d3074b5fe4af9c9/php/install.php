<?php

/**
 * Initiates Installer
 *
 * @package default
 */

require_once dirname(__FILE__).'/include/Installer.class.php';

new Installer();

?>